package mastermind;


import java.util.*;
import java.lang.Math;

public class KaneFrentzmastermind {

        private static Random random = new Random();
        private static Scanner input = new Scanner(System.in);

        public static void main(String[] args) {
            int[] secretCode = new int[4];
            int i;
            boolean gewonnen;

            gewonnen = false;
            int aantalWit;
            int aantalZwart;

            aantalWit = 0;
            aantalZwart = 0;
            int aantalRonde;

            aantalRonde = 0;
            for (i = 0; i <= 3; i++) {
                secretCode[i] = random.nextInt(6);
            }
            System.out.println("De geheime code is ingesteld!");
            for (i = 0; i <= 3; i++) {
            }
            System.out.println("Type the code in here:");
            int[] codeGuess = new int[4];

            codeGuess[0] = input.nextInt();
            codeGuess[1] = input.nextInt();
            codeGuess[2] = input.nextInt();
            codeGuess[3] = input.nextInt();
            while (gewonnen == false && aantalRonde < 11) {
                if (secretCode[0] == codeGuess[0]) {
                    aantalZwart = aantalZwart + 1;
                } else {
                    if (secretCode[0] == codeGuess[1] && secretCode[1] != codeGuess[1]) {
                        aantalWit = aantalWit + 1;
                    } else {
                        if (secretCode[0] == codeGuess[2] && secretCode[2] != codeGuess[2]) {
                            aantalWit = aantalWit + 1;
                        } else {
                            if (secretCode[0] == codeGuess[3] && secretCode[3] != codeGuess[3]) {
                                aantalWit = aantalWit + 1;
                            }
                        }
                    }
                }
                if (secretCode[1] == codeGuess[1]) {
                    aantalZwart = aantalZwart + 1;
                } else {
                    if (secretCode[1] == codeGuess[0] && secretCode[0] != codeGuess[0]) {
                        aantalWit = aantalWit + 1;
                    } else {
                        if (secretCode[1] == codeGuess[2] && secretCode[2] != codeGuess[2]) {
                            aantalWit = aantalWit + 1;
                        } else {
                            if (secretCode[1] == codeGuess[3] && secretCode[3] != codeGuess[3]) {
                                aantalWit = aantalWit + 1;
                            }
                        }
                    }
                }
                if (secretCode[2] == codeGuess[2]) {
                    aantalZwart = aantalZwart + 1;
                } else {
                    if (secretCode[2] == codeGuess[0] && secretCode[0] != codeGuess[0]) {
                        aantalWit = aantalWit + 1;
                    } else {
                        if (secretCode[2] == codeGuess[1] && secretCode[1] != codeGuess[1]) {
                            aantalWit = aantalWit + 1;
                        } else {
                            if (secretCode[2] == codeGuess[3] && secretCode[3] != codeGuess[3]) {
                                aantalWit = aantalWit + 1;
                            }
                        }
                    }
                }
                if (secretCode[3] == codeGuess[3]) {
                    aantalZwart = aantalZwart + 1;
                } else {
                    if (secretCode[3] == codeGuess[0] && secretCode[0] != codeGuess[0]) {
                        aantalWit = aantalWit + 1;
                    } else {
                        if (secretCode[3] == codeGuess[1] && secretCode[1] != codeGuess[1]) {
                            aantalWit = aantalWit + 1;
                        } else {
                            if (secretCode[3] == codeGuess[2] && secretCode[2] != codeGuess[2]) {
                                aantalWit = aantalWit + 1;
                            }
                        }
                    }
                }
                aantalRonde = aantalRonde + 1;
                if (aantalZwart == 4) {
                    gewonnen = true;
                    System.out.println("Je hebt gewonnen in " + aantalRonde+ " rondes!");
                } else {
                    System.out.println("Aantal witte:");
                    System.out.println(aantalWit);
                    System.out.println("Aantal zwarte:");
                    System.out.println(aantalZwart);
                    System.out.println("Voer een nieuwe code in:");
                    aantalWit = 0;
                    aantalZwart = 0;
                    codeGuess[0] = input.nextInt();
                    codeGuess[1] = input.nextInt();
                    codeGuess[2] = input.nextInt();
                    codeGuess[3] = input.nextInt();
                }
            }
            if (aantalRonde > 10) {
                System.out.println("Je hebt verloren");
            }
        }
    }
